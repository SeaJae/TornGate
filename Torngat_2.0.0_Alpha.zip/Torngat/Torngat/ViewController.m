/*
 *
 *   Torngat
 *   Made by 1GamerDev using async_wake by Ian Beer & Fun by theninjaprawn
 *   * MY * code is licensed under DBAD
 *   (c) 2018
 *
 */

#import "ViewController.h"
#include "kmem.h"
#include "async_wake.h"
#include "fun.h"
#import "enterprise_codesigning_credits.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "libproc.h"

#import <sys/utsname.h>
#import "ZipArchive.h"
#import "SSZipArchive.h"
#import "SSZipCommon.h"

#include "Reachability.h"
#import "UIImage+Private.h"
#include "bluetoothd/exploit.h"

// used in if statements to compare the user's iOS version
#define SYSTEM_VERSION_GREATER_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_LESS_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

// hex to rgb
#define hex(hex, alphaVal) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:alphaVal]

// used in if statements to check if the user is disconnected from the internet
#define noWiFi [[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable

// button colours
#define bgDisabledColour setBackgroundColor:hex(0xB8B8B8, 1.0)
#define bgBlueColour setBackgroundColor:hex(0x007AFF, 1.0)

// respringDevice(); to respring the user's device
#define respringDevice() [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade]; UIViewController *r = [self.storyboard instantiateViewControllerWithIdentifier:@"respringv"]; [self presentViewController:r animated:YES completion:nil]

// define unsint as an unsigned int
typedef unsigned int unsint;

NSString *documentsDirectory;
NSString *getDocumentsDirectory() {
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    documentsDirectory = [paths objectAtIndex:0];
    return documentsDirectory;
}
void writeToLocalFile(NSString *name, NSString *contents) {
    getDocumentsDirectory();
    NSString *fileName = [NSString stringWithFormat:@"%@/%@", documentsDirectory, name];
    [contents writeToFile:fileName atomically:NO encoding:NSUTF8StringEncoding error:nil];
}
NSString *stringWithContentsOfLocalFile(NSString *daName) {
    getDocumentsDirectory();
    NSLog(@"%@", [NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", documentsDirectory, daName] encoding:NSUTF8StringEncoding error:nil]);
    return [NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", documentsDirectory, daName] encoding:NSUTF8StringEncoding error:nil];
}
BOOL darkModeIsEnabled(void) {
    getDocumentsDirectory();
    if([[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/darkMode", documentsDirectory] encoding:NSUTF8StringEncoding error:nil] isEqual: @"yes"]) {
        return true;
    } else {
        return false;
    }
}

NSString *versionNumber = @"Version 2.0.0";
NSString *NSVN = @"2.0.0";

NSString *bigFullscreenBoiTitle = @"Loading";
NSString *bigFullscreenBoiText = @"Please Wait";

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIButton *gobtn;
@property (strong, nonatomic) IBOutlet UIWebView *web;
@property (strong, nonatomic) IBOutlet UIProgressView *progress;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UIButton *infoBtn;
@property (strong, nonatomic) IBOutlet UILabel *btnTxt;

@end

@implementation ViewController

mach_port_t get_user_client;
mach_port_t get_tfp0;

int cont = -9999999;

- (void)wrongArch {
    //  there's no reason for this to ever be called since 32bit was dropped in ios 11, but just in case.
    UIAlertController *unsupported = [UIAlertController alertControllerWithTitle:@"Unsupported Architecture" message:@"Torngat does not support 32bit devices." preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:unsupported animated:YES completion:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
#ifdef INTEL86
    [self wrongArch];
#endif
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [_alert setHidden:YES];
    [_alert setAlpha:0.0f];
    [_loader setAlpha:0.0f];
    [_progress setHidden:YES];
    self.gobtn.backgroundColor = [UIColor colorWithRed:171 green:178 blue:186 alpha:1.0f];
    self.gobtn.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    self.gobtn.layer.shadowOffset = CGSizeMake(0, 0);
    self.gobtn.layer.shadowOpacity = 1.0f;
    self.gobtn.layer.shadowRadius = 5;
    self.gobtn.layer.masksToBounds = YES;
    self.gobtn.layer.cornerRadius = 25.0f;
    self.gobtn.exclusiveTouch = YES;
    documentsDirectory = getDocumentsDirectory();
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/darkMode", documentsDirectory]]) {
        writeToLocalFile(@"darkMode", @"no");;
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/showLoader", documentsDirectory]]) {
        writeToLocalFile(@"showLoader", @"yes");
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/autoExploit", documentsDirectory]]) {
        writeToLocalFile(@"autoExploit", @"yes");
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/resizeBootlogos", documentsDirectory]]) {
        writeToLocalFile(@"resizeBootlogos", @"no");
    }
    [_web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://1gamerdev.github.io/Torngat-Files/update.html?version=%@", NSVN]]]];
    if (SYSTEM_VERSION_LESS_THAN(@"11.0") || SYSTEM_VERSION_GREATER_THAN(@"11.2.2")) {} else {
        if ([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
            if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
                escapeSB(&cont);
            } else {
                dispatch_async(dispatch_get_global_queue(0,0), ^{
                    get_tfp0 = go(&get_user_client, &cont);
                });
            }
        }
    }
}

NSInteger btnMem = 0;
// btnMem 0 == iOS versions supported
// btnMem 1 == Current Torngat version

- (IBAction)infoBtn:(id)sender {
    if (btnMem == 0) {
        [_infoBtn setTitle:versionNumber forState:UIControlStateNormal];
        btnMem = 1;
    } else if (btnMem == 1) {
        [_infoBtn setTitle:@"iOS 11 - 11.2.2" forState:UIControlStateNormal];
        btnMem = 0;
    } else {
        [_infoBtn setTitle:@"iOS 11 - 11.2.2" forState:UIControlStateNormal];
        btnMem = 0;
    }
}

- (IBAction)go:(id)sender {
    // keeps away users on unsupported ios versions
    if (SYSTEM_VERSION_LESS_THAN(@"11.0") || SYSTEM_VERSION_GREATER_THAN(@"11.2.2")) {
        UIAlertController *unsupported = [UIAlertController alertControllerWithTitle:@"Unsupported iOS version" message:[NSString stringWithFormat:@"Your iOS version (%@) is unsupported by Torngat.", [[UIDevice currentDevice] systemVersion]] preferredStyle:UIAlertControllerStyleAlert];
        [self presentViewController:unsupported animated:YES completion:nil];
        return;
    }
    UIAlertControllerStyle style;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        style = UIAlertControllerStyleAlert;
    } else {
        style = UIAlertControllerStyleActionSheet;
    }
    UIAlertController *ca = [UIAlertController alertControllerWithTitle:@"Warning" message:@"By using Torngat, you agree that if it causes any damage to your device, you are responsible." preferredStyle:style];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        if (cont == 1) {
            // Already succeeded
            if (SYSTEM_VERSION_LESS_THAN(@"11.2")) {
                unlink("/.write_test");
            } else {
                unlink("/private/var/mobile/write_test");
            }
            [_progress setProgress:1.0];
            if (!darkModeIsEnabled()) {[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
            UIViewController *Done = [self.storyboard instantiateViewControllerWithIdentifier:@"Done"];
            [self presentViewController:Done animated:YES completion:nil];
            [UIView animateWithDuration:0.6f animations:^{
                [_loader setAlpha:0.0f];
            } completion:^(BOOL finished) {
                [_loader stopAnimating];
            }];
            [_progress setProgress:1.0f];
            [_gobtn setEnabled:NO];
        } else {
            [_gobtn setEnabled:NO];
            [_loader startAnimating];
            [UIView animateWithDuration:0.3f animations:^{
                [_btnTxt setAlpha:0.0f];
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.3f animations:^{
                    [_loader setAlpha:1.0f];
                }];
            }];
            [_loader setHidden:NO];
            [_progress setHidden:NO];
            [_progress setProgress:0.6];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{[NSThread sleepForTimeInterval:0.1f];dispatch_async(dispatch_get_main_queue(), ^{
                if([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
            retry:;
                if (cont == -9999999) {
                    // code to execute while exploit is running
                    goto retry;
                } else if (cont == -888888888) {
                    // code to execute while Fun is running (async_wake only)
                    goto retry;
                } else if (cont == 1) {} else {
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setHidden:YES];
                    [_gobtn setEnabled:NO];
                    [_gobtn setTitle:@"Failed" forState:UIControlStateDisabled];
                }} else {
                    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
                        escapeSB(&cont);
                    } else {
                        // async_wake
                        get_tfp0 = go(&get_user_client, &cont);
                    }
                }
                if (SYSTEM_VERSION_LESS_THAN(@"11.2")) {
                unlink("/.write_test");
                if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"]) {
                    printf("Error\n");
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setHidden:YES];
                    [_gobtn setEnabled:NO];
                    [_gobtn setTitle:@"Failed" forState:UIControlStateDisabled];
                } else {
                    printf("/.write_test successfully deleted.\n");
                    [_progress setProgress:1.0];
                    if (!darkModeIsEnabled()) {[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
                    UIViewController *Done = [self.storyboard instantiateViewControllerWithIdentifier:@"Done"];
                    [self presentViewController:Done animated:YES completion:nil];
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setProgress:1.0f];
                    [_gobtn setEnabled:NO];
                }} else {
                    unlink("/private/var/mobile/write_test");
                    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/mobile/write_test"]) {
                        printf("Error\n");
                        [UIView animateWithDuration:0.6f animations:^{
                            [_loader setAlpha:0.0f];
                        } completion:^(BOOL finished) {
                            [_loader stopAnimating];
                        }];
                        [_progress setHidden:YES];
                        [_gobtn setEnabled:NO];
                        [_gobtn setTitle:@"Failed" forState:UIControlStateDisabled];
                    } else {
                        printf("/private/var/write_test successfully deleted.\n");
                        [_progress setProgress:1.0];
                        if (!darkModeIsEnabled()) {[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
                        UIViewController *Done = [self.storyboard instantiateViewControllerWithIdentifier:@"Done"];
                        [self presentViewController:Done animated:YES completion:nil];
                        [UIView animateWithDuration:0.6f animations:^{
                            [_loader setAlpha:0.0f];
                        } completion:^(BOOL finished) {
                            [_loader stopAnimating];
                        }];
                        [_progress setProgress:1.0f];
                        [_gobtn setEnabled:NO];
                    }
                }
            });});
        }
    }];
    [ca addAction:ok];
    [ca addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) { exit(0); }]];
    [self presentViewController:ca animated:YES completion:nil];
}

@end

@interface Done ()
@property (strong, nonatomic) IBOutlet UIView *tweaks;
@property (strong, nonatomic) IBOutlet UIView *credits;
@property (strong, nonatomic) IBOutlet UITabBar *tabBar;
@property (strong, nonatomic) IBOutlet UITabBarItem *homeTab;
@property (strong, nonatomic) IBOutlet UITabBarItem *creditsTab;
@property (strong, nonatomic) IBOutlet UITabBarItem *aboutTab;
@property (strong, nonatomic) IBOutlet UIView *about;
@property (strong, nonatomic) IBOutlet UIView *settings;
@property (strong, nonatomic) IBOutlet UITabBarItem *settingsTab;

@end

@implementation Done

- (void)respring {
    respringDevice();
}

- (void)visualStyle {
    if (darkModeIsEnabled()) {
        _tabBar.barStyle = UIBarStyleBlack;
    } else {
        _tabBar.barStyle = UIBarStyleDefault;
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tweaks setHidden:NO];
    [self.credits setHidden:YES];
    [self.about setHidden:YES];
    [self.settings setHidden:YES];
    _tabBar.delegate = self;
    [_tabBar setSelectedItem:_homeTab];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
    if (item == _homeTab) {
        [self.tweaks setHidden:NO];
        [self.credits setHidden:YES];
        [self.about setHidden:YES];
        [self.settings setHidden:YES];
    } else if (item == _creditsTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:NO];
        [self.about setHidden:YES];
        [self.settings setHidden:YES];
    } else if (item == _aboutTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:YES];
        [self.about setHidden:NO];
        [self.settings setHidden:YES];
    } else if (item == _settingsTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:YES];
        [self.about setHidden:YES];
        [self.settings setHidden:NO];
    } else {
        exit(0);
    }
}

@end

@interface tweaksView ()
@property (strong, nonatomic) IBOutlet UIButton *resbtn;
@property (strong, nonatomic) IBOutlet UIButton *cc;
@property (strong, nonatomic) IBOutlet UIButton *rebootbtn;
@property (strong, nonatomic) IBOutlet UIButton *brb;
@property (strong, nonatomic) IBOutlet UIButton *bub;
@property (strong, nonatomic) IBOutlet UIWebView *web;
@property (strong, nonatomic) IBOutlet UIButton *maskBtn;
@property (strong, nonatomic) IBOutlet UIButton *bootlogo;
@property (strong, nonatomic) IBOutlet UIButton *fontsBtn;
@property (strong, nonatomic) IBOutlet UIButton *badgeBtn;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UIView *sticky;
@property (strong, nonatomic) IBOutlet UIButton *dscb;
@property (strong, nonatomic) IBOutlet UIButton *exit;

@end

@implementation tweaksView

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)bootlogo:(id)sender {
    [self sVC:@"bootlogo"];
}

- (IBAction)exit:(id)sender {
    respringDevice();
}

- (IBAction)dscb:(id)sender {
    [self sVC:@"dockLine"];
}

- (void)applyBtn:(UIButton*)buttonIdentifier {
    if (darkModeIsEnabled()) {
        buttonIdentifier.backgroundColor = hex(0x544D45, 1.0);
        [buttonIdentifier setTitleColor:hex(0xFFFFFF, 1.0) forState:UIControlStateNormal];
    } else {
        buttonIdentifier.backgroundColor = [UIColor colorWithRed:171 green:178 blue:186 alpha:1.0f];
        [buttonIdentifier setTitleColor:hex(0x000000, 1.0) forState:UIControlStateNormal];
    }
    buttonIdentifier.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    buttonIdentifier.layer.shadowOffset = CGSizeMake(0, 0/*2*/);
    buttonIdentifier.layer.shadowOpacity = 1.0f;
    buttonIdentifier.layer.shadowRadius = 5/*0*/;
    buttonIdentifier.layer.masksToBounds = NO;
    buttonIdentifier.layer.cornerRadius = 10.0f/*2*/;
    buttonIdentifier.exclusiveTouch = YES;
    if (SYSTEM_VERSION_LESS_THAN(@"11.1")) {
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
    }
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [_dscb setEnabled:NO];
        [_dscb bgDisabledColour];
    }
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
        [_brb setEnabled:NO];
        [_brb bgDisabledColour];
        [_maskBtn setEnabled:NO];
        [_maskBtn bgDisabledColour];
        [_bootlogo setEnabled:NO];
        [_bootlogo bgDisabledColour];
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
        [_sticky setHidden:YES];
        [_rebootbtn setHidden:YES];
    }
}

- (void)visualStyle {
    if (darkModeIsEnabled()) {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.view setBackgroundColor:[UIColor blackColor]];
        [self.sticky setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.45f]];
    } else {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.view setBackgroundColor:[UIColor whiteColor]];
        [self.sticky setBackgroundColor:hex(0xEBEBF1, 0.65)];
    }
    [self applyBtn:_resbtn];
    [self applyBtn:_cc];
    [self applyBtn:_rebootbtn];
    [self applyBtn:_brb];
    [self applyBtn:_bub];
    [self applyBtn:_maskBtn];
    [self applyBtn:_bootlogo];
    [self applyBtn:_badgeBtn];
    [self applyBtn:_dscb];
    [self applyBtn:_exit];
    [_exit setBackgroundColor:[UIColor redColor]];
    [_exit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    if (!file_exist("/System/Library/Fonts/Core/AppleColorEmoji.ttc") && !file_exist("/System/Library/Fonts/Core/AppleColorEmoji@1x.ttc") && file_exist("/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc") && !file_exist("/System/Library/Fonts/Core/AppleColorEmoji@3x.ttc")) {
        [self applyBtn:_fontsBtn];
    } else {
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

- (void)sVC:(NSString*)vc {
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:vc];
    viewController.providesPresentationContextTransitionStyle = YES;
    viewController.definesPresentationContext = YES;
    [viewController setModalPresentationStyle:UIModalPresentationOverFullScreen];
    [self presentViewController:viewController animated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)changeResolution:(id)sender {
    [self sVC:@"res"];
}

- (IBAction)blockRevokes:(id)sender {
    [self sVC:@"blockRevokes"];
}

- (IBAction)blockUpdates:(id)sender {
    [self sVC:@"blockUpdates"];
}

- (IBAction)masks:(id)sender {
    [self sVC:@"Masks"];
}

- (IBAction)badge:(id)sender {
    [self sVC:@"badges"];
}

- (IBAction)fonts:(id)sender {
    [self sVC:@"fonts"];
}

- (IBAction)exitApp:(id)sender {
    exit(0);
    assert(NO);
}

- (void)request:(NSString *)address {
    NSURL *url = [NSURL URLWithString:address];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_web loadRequest:urlRequest];
}

- (void)viewDidLayoutSubviews {
    struct utsname u;
    uname(&u);
    if (SYSTEM_VERSION_LESS_THAN(@"11.2")) {
        if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 266);
        } else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 171);
        } else if (strcmp(u.machine, "iPhone7,1") == 0 || strcmp(u.machine, "iPhone8,2") == 0 || strcmp(u.machine, "iPhone9,2") == 0 || strcmp(u.machine, "iPhone9,4") == 0 || strcmp(u.machine, "iPhone10,2") == 0 || strcmp(u.machine, "iPhone10,5") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 156);
        } else if (strcmp(u.machine, "iPhone10,3") == 0 || strcmp(u.machine, "iPhone10,6") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 151);
        }
    } else {
        if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 266 - _sticky.frame.size.height);
        } else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 171 - _sticky.frame.size.height);
        } else if (strcmp(u.machine, "iPhone7,1") == 0 || strcmp(u.machine, "iPhone8,2") == 0 || strcmp(u.machine, "iPhone9,2") == 0 || strcmp(u.machine, "iPhone9,4") == 0 || strcmp(u.machine, "iPhone10,2") == 0 || strcmp(u.machine, "iPhone10,5") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 156 - _sticky.frame.size.height);
        } else if (strcmp(u.machine, "iPhone10,3") == 0 || strcmp(u.machine, "iPhone10,6") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 151 - _sticky.frame.size.height);
        }
    }
}

@end

@interface blockRevokes ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;

@end

@implementation blockRevokes

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (void)check {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [_block setTitle:@"Unblock" forState:UIControlStateNormal];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    } else {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    }
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_block];
    [self applyBtn:_cancel];
    [self check];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)block:(id)sender {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been unblocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else {
        NSString *str = [NSString stringWithFormat:@"%@\n127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com", [NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil]];
        [str writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    }
}

@end

@interface blockUpdates ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextView *desc;
@property (strong, nonatomic) IBOutlet UIWebView *web;

@end

@implementation blockUpdates

- (void)request:(NSString *)address {
    NSURL *url = [NSURL URLWithString:address];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_web loadRequest:urlRequest];
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)check {
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
    return;
    } else {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"]) {
        [_block setTitle:@"Unblock" forState:UIControlStateNormal];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"]) {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    } else {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    }
    }
}

- (void)viewWillAppear:(BOOL)animated {
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
        _desc.text = @"Enabling this feature will block OTA updates.  This can only be disabled by removing the tvOS beta profile found in Settings > General > Device Management.";
    }
    [self applyBtn:_block];
    [self applyBtn:_cancel];
    [self check];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)block:(id)sender {
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
    [self request:@"about:blank"];
    [self request:@"http://1gamerdev.github.io/Torngat-Files/tvOS_11_beta_Profile.mobileconfig"];
    [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
    NSLog(@"%@", [NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil]);
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been unblocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else {
        NSString *str = [NSString stringWithFormat:@"%@\n127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com", [NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil]];
        [str writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    }
    }
}

@end

@interface res ()
@property (strong, nonatomic) IBOutlet UITextField *h;
@property (strong, nonatomic) IBOutlet UITextField *w;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIButton *xBtn;

@end

@implementation res

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (IBAction)dismissKeyboard:(id)sender {
    [self.view endEditing:YES];
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (NSString *)machineName
{
    struct utsname systemInfo;
    uname(&systemInfo);
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)continueChangeRes {
    [self calertd];
    NSString *width = _w.text;
    NSString *height = _h.text;
    width = [width stringByReplacingOccurrencesOfString:@"px" withString:@""];
    height = [height stringByReplacingOccurrencesOfString:@"px" withString:@""];
    NSDictionary *res = [NSDictionary dictionaryWithContentsOfFile:@"/private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist"];
    [res setValue:height forKey:@"canvas_height"];
    [res setValue:width forKey:@"canvas_width"];
    [res writeToFile:@"/private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist" atomically:YES];
    [self calertd];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [NSThread sleepForTimeInterval:0.6f];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self calert:@"Success" alertMessage:@"Please reboot your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        });
    });
}

- (IBAction)change:(id)sender {
    NSString *width = _w.text;
    NSString *height = _h.text;
    width = [width stringByReplacingOccurrencesOfString:@"px" withString:@""];
    height = [height stringByReplacingOccurrencesOfString:@"px" withString:@""];
    if (width != NULL && height != NULL && ![width isEqual: @""] && ![height  isEqual: @""]) {
        NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        if ([width rangeOfCharacterFromSet:notDigits].location == NSNotFound && [height rangeOfCharacterFromSet:notDigits].location == NSNotFound)
        {
            if (![width containsString:@"."] && ![height containsString:@"."]) {
                [self calert:@"Confirmation" alertMessage:@"Changing your resolution may cause unintended side-effects or even stop your device from functioning.  Are you sure you'd like to continue?  (Please make sure you have a backup of your data, because if something goes wrong, you'll have to restore your device via iCloud then load the backup)" dismissButton:@"Continue" buttonVis:2 dismissBtnAction:@selector(continueChangeRes)];
            } else {
                [self calert:@"Error" alertMessage:@"Your width / height may not contain a decimal point." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Error" alertMessage:@"Your width / height may only be numeric." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
        } } else {
            [self calert:@"Error" alertMessage:@"Please provide the width and height of your new resolution." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
        }
}

@end

@interface cc ()
@property (strong, nonatomic) IBOutlet UIButton *e1btn;
@property (strong, nonatomic) IBOutlet UIButton *d1btn;
@property (strong, nonatomic) IBOutlet UISlider *audio;
@property (strong, nonatomic) IBOutlet UISlider *brightness;
@property (strong, nonatomic) IBOutlet UIButton *e2btn;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *shortDesc;
@property (strong, nonatomic) IBOutlet UILabel *desc;
@property (strong, nonatomic) IBOutlet UILabel *audioVal;
@property (strong, nonatomic) IBOutlet UILabel *brightnessVal;
@property (strong, nonatomic) IBOutlet UILabel *customisationText;
@property (strong, nonatomic) IBOutlet UILabel *brightnessModuleText;
@property (strong, nonatomic) IBOutlet UILabel *audioModuleText;
@property (strong, nonatomic) IBOutlet UITextView *cusomisationDescription;

@end

@implementation cc

NSString *cc_s1_on;
char *cc_s1_on_char;

- (void)calert {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"bigFullscreenBoi"];
    viewController.providesPresentationContextTransitionStyle = YES;
    viewController.definesPresentationContext = YES;
    [viewController setModalPresentationStyle:UIModalPresentationOverFullScreen];
    [self presentViewController:viewController animated:NO completion:nil];
}

- (void)e1go:(NSString *)path {
    NSError *error;
    NSData *data = [NSData dataWithContentsOfFile:path];
    id plistFile = [NSPropertyListSerialization propertyListWithData:data options:0 format:NULL error:&error];
    NSData *asXML = [NSPropertyListSerialization dataWithPropertyList:plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    NSLog(@"%@\n", [[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding]);
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *strr = [[[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSLog(@"%@\n", strr);
    NSString *str = [[strr componentsJoinedByString:@""] stringByReplacingOccurrencesOfString:@"<key>fixed</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string></array>" withString:@"<key>fixed</key><array></array>"];
    NSLog(@"%@\n", str);
    str = [str stringByReplacingOccurrencesOfString:@"<key>user-enabled</key><array>" withString:@"<key>user-enabled</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string>"];
    NSLog(@"%@\n", str);
    str = [str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
    NSLog(@"%@\n", str);
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
    NSLog(@"%@", [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil]);
    [[NSFileManager defaultManager] createFileAtPath:cc_s1_on contents:nil attributes:nil];
    [self s1];
}

- (void)d1go:(NSString *)path {
    NSError *error;
    NSData *data = [NSData dataWithContentsOfFile:path];
    id plistFile = [NSPropertyListSerialization propertyListWithData:data options:0 format:NULL error:&error];
    NSData *asXML = [NSPropertyListSerialization dataWithPropertyList:plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *strr = [[[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *str = [[strr componentsJoinedByString:@""] stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string>" withString:@""];
    str = [str stringByReplacingOccurrencesOfString:@"<key>fixed</key><array/>" withString:@"<key>fixed</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string></array>"];
    str = [str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSData *_data = [NSData dataWithContentsOfFile:@"/private/var/mobile/Library/ControlCenter/ModuleConfiguration.plist"];
    id _plistFile = [NSPropertyListSerialization propertyListWithData:_data options:0 format:NULL error:&error];
    NSData *_asXML = [NSPropertyListSerialization dataWithPropertyList:_plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *_strr = [[[NSString alloc] initWithData:_asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *_str = [_strr componentsJoinedByString:@""];
    NSString *compare = [_strr componentsJoinedByString:@""];
    if ([_str containsString:@"<string>com.apple.control-center.ConnectivityModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.ConnectivityModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.mediaremote.controlcenter.nowplaying</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.mediaremote.controlcenter.nowplaying</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.OrientationLockModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.OrientationLockModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.DoNotDisturbModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.DoNotDisturbModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.DisplayModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.DisplayModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.AudioModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.AudioModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.mediaremote.controlcenter.airplaymirroring</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.mediaremote.controlcenter.airplaymirroring</string>" withString:@""];
    } if (![_str isEqual: compare]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
        [_str writeToFile:@"/private/var/mobile/Library/ControlCenter/ModuleConfiguration.plist" atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    unlink(cc_s1_on_char);
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
    [self s1];
}

- (void)e2go:(NSString *)path {
    NSString *str = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\"><dict><key>com.apple.Home.ControlCenter</key><dict><key>size</key><dict><key>height</key><integer>1</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.control-center.AudioModule</key><dict><key>size</key><dict><key>height</key><integer>%i</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.control-center.ConnectivityModule</key><dict><key>size</key><dict><key>height</key><integer>2</integer><key>width</key><integer>2</integer></dict></dict><key>com.apple.control-center.DisplayModule</key><dict><key>size</key><dict><key>height</key><integer>%i</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.mediaremote.controlcenter.airplaymirroring</key><dict><key>size</key><dict><key>width</key><integer>2</integer></dict></dict><key>com.apple.mediaremote.controlcenter.nowplaying</key><dict><key>size</key><dict><key>height</key><integer>2</integer><key>width</key><integer>2</integer></dict></dict></dict></plist>", (int)_audio.value, (int)_brightness.value];
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
}

- (IBAction)e1:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (IBAction)d1:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)s1 {
    if ([[NSFileManager defaultManager] fileExistsAtPath:cc_s1_on]) {
        [_e1btn setEnabled:NO];
        [_d1btn setEnabled:YES];
        [UIView animateWithDuration:0.5f animations:^{
            [_e1btn setBackgroundColor:hex(0xB8B8B8, 1.0)]; [_d1btn setBackgroundColor:hex(0xFF0033, 1.0)];
        }];
    } else {
        [_e1btn setEnabled:YES];
        [_d1btn setEnabled:NO];
        [UIView animateWithDuration:0.5f animations:^{
            [_e1btn setBackgroundColor:hex(0x007AFF, 1.0)]; [_d1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
        }];
    }
}

- (IBAction)e2:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~iphone.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipad.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipod.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (void)updateValTexts {
    [_audioVal setText:[NSString stringWithFormat:@"%i", (int)_audio.value]];
     [_brightnessVal setText:[NSString stringWithFormat:@"%i", (int)_brightness.value]];
}

- (void)visualStyle {
    if (darkModeIsEnabled()) {
        _customisationText.textColor = [UIColor lightTextColor];
        _cusomisationDescription.textColor = [UIColor lightTextColor];
        _audioModuleText.textColor = [UIColor lightTextColor];
        _brightnessModuleText.textColor = [UIColor lightTextColor];
        _audioVal.textColor = [UIColor lightTextColor];
        _brightnessVal.textColor = [UIColor lightTextColor];
        self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
        self.view.backgroundColor = [UIColor blackColor];
    } else {
        _customisationText.textColor = [UIColor darkTextColor];
        _cusomisationDescription.textColor = [UIColor darkTextColor];
        _audioModuleText.textColor = [UIColor darkTextColor];
        _brightnessModuleText.textColor = [UIColor darkTextColor];
        _audioVal.textColor = [UIColor darkTextColor];
        _brightnessVal.textColor = [UIColor darkTextColor];
        self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
        self.view.backgroundColor = [UIColor whiteColor];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
        cc_s1_on = @"/private/var/mobile/cc_s1_on";
        cc_s1_on_char = "/private/var/mobile/cc_s1_on";
    } else {
        cc_s1_on = @"/.cc_s1_on";
        cc_s1_on_char = "/.cc_s1_on";
    }
    [self applyBtn:_e1btn];
    [self applyBtn:_d1btn];
    [self applyBtn:_e2btn];
    if ([[NSFileManager defaultManager] fileExistsAtPath:cc_s1_on]) {
        [_e1btn setEnabled:NO];
        [_d1btn setEnabled:YES];
        [_e1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
        [_d1btn setBackgroundColor:hex(0xFF0033, 1.0)];
    } else {
        [_e1btn setEnabled:YES];
        [_d1btn setEnabled:NO];
        [_e1btn setBackgroundColor:hex(0x007AFF, 1.0)];
        [_d1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
    }
    [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(updateValTexts) userInfo:nil repeats:YES];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

- (void)viewDidLayoutSubviews {
    if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad) {
        struct utsname u;
        uname(&u);
        //NSLog(@"%@", [NSString stringWithUTF8String:u.machine]);
        if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 175);
        } else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 40);
        }
    }
}

@end

@interface Masks ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextField *custommaskurl;
@property (strong, nonatomic) IBOutlet UIView *urlalert;
@property (strong, nonatomic) IBOutlet UIView *wait;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;

@end

@implementation Masks

- (IBAction)respringAction:(id)sender {
    respringDevice();
}

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setAlpha:1.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
        } completion:^(BOOL finished) {
            [_wait setHidden:YES];
        }];
    }
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)checkWiFiC {
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_custom bgDisabledColour];
        }];
        [_custom setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_custom bgBlueColour];
        }];
        [_custom setEnabled:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_custom];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)applyMask:(NSString *)zipName {
    [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:zipName ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/"];
    [self moveFiles];
    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" error:nil];    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" error:nil];
    [[NSFileManager defaultManager] createDirectoryAtPath:@"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" withIntermediateDirectories:false attributes:nil error:nil];
    if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)change:(id)sender {
    NSInteger selectedSegment = _o.selectedSegmentIndex;
    if (selectedSegment == 0) {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self applyMask:@"iPadDefault"];
        } else {
            [self applyMask:@"iPhoneDefault"];
        }
    } else if (selectedSegment == 1) {
        [self applyMask:@"Circle"];
    } else if (selectedSegment == 2) {
        [self applyMask:@"Leaf"];
    } else if (selectedSegment == 3) {
        [self applyMask:@"Tag"];
    } else {
        [self calert:@"Failed" alertMessage:@"Please select a mask." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (void)moveFiles {
    BOOL isDir;
    NSString *oPath = @"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/";
    [[NSFileManager defaultManager] fileExistsAtPath:oPath isDirectory:&isDir];
    if(isDir) {
        NSArray *contentOfDirectory = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:oPath error:NULL];
        int contentcount = (int)[contentOfDirectory count];
        int i;
        for(i = 0; i < contentcount; i++) {
            NSString *fileName = [[contentOfDirectory objectAtIndex:i] stringByReplacingOccurrencesOfString:@"/" withString:@""];
            NSString *origPath = [NSString stringWithFormat:@"%@%@", oPath, fileName];
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] isDirectory:nil]) {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] error:nil];
                [[NSFileManager defaultManager] copyItemAtPath:origPath toPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] error:nil];
            }
        }
    }
}

- (IBAction)continueCustom:(id)sender {
    [_urlalert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [self.view endEditing:YES];
    [_cancel setEnabled:NO];
    [_custom setEnabled:NO];
    [_change setEnabled:NO];
    [_o setEnabled:NO];
    [UIView animateWithDuration:0.5f animations:^{
        [_urlalert setAlpha:0.0f]; [_X setAlpha:0.0f];
    } completion:^(BOOL finished){[self.view endEditing:YES];_custommaskurl.text = @"";[self.view endEditing:YES];}];
    NSURL *url = [NSURL URLWithString:_custommaskurl.text];
    NSUInteger length = [_custommaskurl.text length];
    NSLog(@"URL: ==>%@<==", url);
    if (length != 0) {
        if ([[[self getFE:url] lowercaseString] isEqual: @"zip"] || [[[self getFE:url] lowercaseString] isEqual: @"tgm"] || [[[self getFE:url] lowercaseString] isEqual: @"mask"]) {
            [self waitK];
            NSData *urlData = [NSData dataWithContentsOfURL:url];
            if (urlData)
            {
                [urlData writeToFile:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" atomically:YES];
                [[NSFileManager defaultManager] createDirectoryAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" withIntermediateDirectories:NO attributes:nil error:nil];
                [SSZipArchive unzipFileAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" toDestination:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/"];
                [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" error:nil];
                [self moveFiles];
                [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" error:nil];
                [[NSFileManager defaultManager] removeItemAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" error:nil];
                [[NSFileManager defaultManager] createDirectoryAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" withIntermediateDirectories:false attributes:nil error:nil];
                if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
                [self doneWaiting];
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                [_cancel setEnabled:YES];
                [_custom setEnabled:YES];
                [_change setEnabled:YES];
                [_o setEnabled:YES];
            } else {
                [self doneWaiting];
                [self calert:@"Failed" alertMessage:@"No data was received." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                [_cancel setEnabled:YES];
                [_custom setEnabled:YES];
                [_change setEnabled:YES];
                [_o setEnabled:YES];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Unsupported file format." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            [_cancel setEnabled:YES];
            [_custom setEnabled:YES];
            [_change setEnabled:YES];
            [_o setEnabled:YES];
        }} else {
            [self calert:@"Failed" alertMessage:@"No URL was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            [_cancel setEnabled:YES];
            [_custom setEnabled:YES];
            [_change setEnabled:YES];
            [_o setEnabled:YES];
        }
    [self.view endEditing:YES];
}

- (IBAction)custom:(id)sender {
    [_urlalert setAlpha:0.0];
    [_X setAlpha:0.0];
    [_urlalert setHidden:NO];
    [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_urlalert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (IBAction)closeURLAlert:(id)sender {
    [self.view endEditing:YES];
    [_urlalert setAlpha:1.0f];
    [UIView animateWithDuration:0.7f animations:^{
        [_urlalert setAlpha:0.0f];
    } completion:^(BOOL finished){[self.view endEditing:YES];_custommaskurl.text = @"";[self.view endEditing:YES];}];
}

@end

@interface bootlogo ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *wait;

@end

@implementation bootlogo

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setAlpha:1.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
        } completion:^(BOOL finished) {
            [_wait setHidden:YES];
        }];
    }
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)revertBtn {
    [_revert setEnabled:YES];
    [_revert setBackgroundColor:hex(0x007AFF, 1.0)];
}

- (void)checkWiFiC {
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgDisabledColour];
        }];
        [_change setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgBlueColour];
        }];
        [_change setEnabled:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_revert];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self revertBtn];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (BOOL)writeBootlogo:(NSData*)urlData {
    BOOL BOOLEAN_RET = FALSE;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~ipad.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~ipad.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    } else {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~iphone.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    }
    [self doneWaiting];
    [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    [self revertBtn];
    return BOOLEAN_RET;
}

- (BOOL)writeBootlogoWithSize:(NSData*)urlData {
    BOOL BOOLEAN_RET = FALSE;
    NSLog(@"%ld", lround([UIScreen mainScreen].scale));
    UIImage *bootlogoToResize = [UIImage imageWithData:urlData];
    CGSize cgsize;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        if (lround([UIScreen mainScreen].scale) == 2) {
            cgsize = CGSizeMake(225.0, 278.0);
        } else if (lround([UIScreen mainScreen].scale) == 3) {
            cgsize = CGSizeMake(339.0, 417.0);
        } else {
            cgsize = CGSizeMake(113.0, 139.0);
        }
    } else {
        if (lround([UIScreen mainScreen].scale) == 2) {
            cgsize = CGSizeMake(129.0, 158.0);
        } else if (lround([UIScreen mainScreen].scale) == 3) {
            cgsize = CGSizeMake(194.0, 237.0);
        } else {
            cgsize = CGSizeMake(65.0, 79.0);
        }
    }
    UIGraphicsBeginImageContextWithOptions(cgsize, NO, 0.0);
    [bootlogoToResize drawInRect:CGRectMake(0, 0, cgsize.width, cgsize.height)];
    bootlogoToResize = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    urlData = UIImagePNGRepresentation(bootlogoToResize);
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~ipad.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~ipad.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    } else {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~iphone.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    }
    return BOOLEAN_RET;
}

- (IBAction)change:(id)sender {
    [self waitK];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) { [NSThread sleepForTimeInterval:0.5f]; }
        dispatch_async(dispatch_get_main_queue(), ^{
                NSURL *url = [NSURL URLWithString:_urlf.text];
                if (![_urlf.text isEqual: @""]) {
                    if ([[[self getFE:url] lowercaseString] isEqual: @"jpg"] || [[[self getFE:url] lowercaseString] isEqual: @"jpeg"] || [[[self getFE:url] lowercaseString] isEqual: @"png"] || [[[self getFE:url] lowercaseString] isEqual: @"ico"]) {
                        NSData *urlData = [NSData dataWithContentsOfURL:url];
                        if (urlData) {
                            if([stringWithContentsOfLocalFile(@"resizeBootlogos") isEqual: @"yes"]) {
                                [self writeBootlogoWithSize:urlData];
                                [self doneWaiting];
                                [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                                [self revertBtn];
                            } else {
                                [self writeBootlogo:urlData];
                                [self doneWaiting];
                                [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                                [self revertBtn];
                            }
                        } else {
                            [self doneWaiting];
                            [self calert:@"Failed" alertMessage:@"No data was received." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                        }
                    } else {
                        [self doneWaiting];
                        [self calert:@"Failed" alertMessage:@"Unsupported file format." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                    }
                } else {
                    [self doneWaiting];
                    [self calert:@"Failed" alertMessage:@"No URL was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                }
        });
    });
}

- (IBAction)revert:(id)sender {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:@"iPadProgressUI" ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/"];
    } else {
        [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:@"iPhoneProgressUI" ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/"];
    }
    BOOL isDir;
    NSString *oPath = @"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/";
    [[NSFileManager defaultManager] fileExistsAtPath:oPath isDirectory:&isDir];
    if(isDir) {
        NSArray *contentOfDirectory = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:oPath error:NULL];
        int contentcount = (int)[contentOfDirectory count];
        int i;
        for(i = 0; i < contentcount; i++) {
            NSString *fileName = [[contentOfDirectory objectAtIndex:i] stringByReplacingOccurrencesOfString:@"/" withString:@""];
            NSString *origPath = [NSString stringWithFormat:@"%@%@", oPath, fileName];
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] isDirectory:nil]) {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] error:nil];
                [[NSFileManager defaultManager] copyItemAtPath:origPath toPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] error:nil];
            }
        }
    }
    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/" error:nil];
    [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface respringv ()
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;

@end

@implementation respringv

- (void)viewWillAppear:(BOOL)animated {
    [_loader startAnimating];
}

- (void)actuallyDoIt {
    kill(backboardd(), SIGKILL);
}

- (void)viewDidLayoutSubviews {
    [self performSelector:@selector(actuallyDoIt) withObject:nil afterDelay:0.8];
}

@end

@interface credits ()
@property (strong, nonatomic) IBOutlet UILabel *exploit;
@property (strong, nonatomic) IBOutlet UILabel *exploitDev;
@property (strong, nonatomic) IBOutlet UILabel *exploitFork;
@property (strong, nonatomic) IBOutlet UILabel *exploitForkDev;
@property (strong, nonatomic) IBOutlet UIImageView *exploitDevImg;
@property (strong, nonatomic) IBOutlet UIImageView *exploitForkDevImg;
@property (strong, nonatomic) IBOutlet UIImageView *me;
@property (strong, nonatomic) IBOutlet UIImageView *skitty;
@property (strong, nonatomic) IBOutlet UIImageView *b;
@property (strong, nonatomic) IBOutlet UIImageView *enterpriseCodeSignerIcon;
@property (strong, nonatomic) IBOutlet UIView *lol;
@property (strong, nonatomic) IBOutlet UIView *official;
@property (strong, nonatomic) IBOutlet UILabel *codesignerName;
@property (strong, nonatomic) IBOutlet UIView *seven;
@property (strong, nonatomic) IBOutlet UILabel *officialURL;

@end

@implementation credits

- (void)addCornerRadiusAndABorderTo:(UIView*)identifier {
    identifier.layer.cornerRadius = 10.0f;
    identifier.layer.borderColor = hex(0xEBEBF1, 1.0).CGColor;
    identifier.layer.borderWidth = 1.0f;
}

- (void)visualStyle {
    if (darkModeIsEnabled()) {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.view setBackgroundColor:[UIColor blackColor]];
        [_official setBackgroundColor:[UIColor blackColor]];
        [_officialURL setTextColor:[UIColor whiteColor]];
    } else {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.view setBackgroundColor:[UIColor whiteColor]];
        [_official setBackgroundColor:[UIColor whiteColor]];
        [_officialURL setTextColor:[UIColor blackColor]];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self addCornerRadiusAndABorderTo:_one];
    [self addCornerRadiusAndABorderTo:_two];
    [self addCornerRadiusAndABorderTo:_three];
    [self addCornerRadiusAndABorderTo:_four];
    [self addCornerRadiusAndABorderTo:_five];
    [self addCornerRadiusAndABorderTo:_six];
    if (![codesigner isEqual: @"Your username / alias"]) {
        [self addCornerRadiusAndABorderTo:_seven];
    } else {
        _seven.layer.cornerRadius = 10.0f;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

NSData *imageData;

BOOL WiFi;

NSString *exploitDevIconURL = @"";
NSString *exploitForkDevIconURL = @"";
NSString *exploitDev = @"";
NSString *exploitForkDev = @"";
NSString *exploit = @"";
NSString *exploitFork = @"";
NSTimer *timer;

- (void)checkWiFiC {
    if (WiFi == YES) {
        return;
    } else {
        if (noWiFi) {
            return;
        } else {
            if (noWiFi) {
                return;
            } else {
                dispatch_async(dispatch_get_global_queue(0,0), ^{
                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitDevIconURL]];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        _exploitDevImg.image = [UIImage imageWithData:imageData];
                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitForkDevIconURL]];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                _exploitForkDevImg.image = [UIImage imageWithData:imageData];
                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:@"https://php.eclipseemu.me/twitter/?id=1GamerDev"]];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        _me.image = [UIImage imageWithData:imageData];
                                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://php.eclipseemu.me/twitter/?id=Skittyblock"]];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                _skitty.image = [UIImage imageWithData:imageData];
                                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://php.eclipseemu.me/twitter/?id=B1n4r1b01"]];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        _b.image = [UIImage imageWithData:imageData];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            _b.image = [UIImage imageWithData:imageData];
                                                            dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:@"https://maxcdn.icons8.com/Share/icon/color/Logos/icons8_logo1600.png"]];
                                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                                    _icons8.image = [UIImage imageWithData:imageData];
                                                                    dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                        if (![codesigner isEqual: @"Your username / alias"]) {
                                                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: codesignerIcon]];
                                                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                                                _enterpriseCodeSignerIcon.image = [UIImage imageWithData:imageData];
                                                                                imageData = NULL;
                                                                            });
                                                                        } else {
                                                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                                                imageData = NULL;
                                                                            });
                                                                        }
                                                                        [timer invalidate];
                                                                        timer = nil;
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }}
    }
}

- (void)roundCredits {
    _one.layer.masksToBounds = YES;
    _two.layer.masksToBounds = YES;
    _three.layer.masksToBounds = YES;
    _four.layer.masksToBounds = YES;
    _five.layer.masksToBounds = YES;
    _six.layer.masksToBounds = YES;
    _seven.layer.masksToBounds = YES;
    _one.clipsToBounds = YES;
    _two.clipsToBounds = YES;
    _three.clipsToBounds = YES;
    _four.clipsToBounds = YES;
    _five.clipsToBounds = YES;
    _six.clipsToBounds = YES;
    _seven.clipsToBounds = YES;
}

- (void)viewDidLoad {
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
        exploitForkDevIconURL = @"Wherever";
        exploitDevIconURL = @"https://php.eclipseemu.me/twitter/?id=raniXCH";
        exploitDev = @"raniXCH";
        exploitForkDev = @"Whomever";
        exploit = @"Vulnerability";
        exploitFork = @"Exploit";
    } else {
        exploitForkDevIconURL = @"https://php.eclipseemu.me/twitter/?id=theninjaprawn";
        exploitDevIconURL = @"https://php.eclipseemu.me/twitter/?id=i41nbeer";
        exploitDev = @"i41nbeer";
        exploitForkDev = @"theninjaprawn";
        exploit = @"async_wake";
        exploitFork = @"Fun";
    }
    [_exploitDev setText:exploitDev];
    [_exploitForkDev setText:exploitForkDev];
    [_exploit setText:exploit];
    [_exploitFork setText:exploitFork];
    if (![codesigner isEqual: @"Your username / alias"]) {
        [_codesignerName setText:codesigner];
        [_official setHidden:YES];
    }
    if (noWiFi) {
        _exploitDevImg.image = [UIImage imageNamed:@"q.png"];
        _exploitForkDevImg.image = [UIImage imageNamed:@"q.png"];
        _me.image = [UIImage imageNamed:@"q.png"];
        _skitty.image = [UIImage imageNamed:@"q.png"];
        _b.image = [UIImage imageNamed:@"q.png"];
        _enterpriseCodeSignerIcon.image = [UIImage imageNamed:@"q.png"];
        _icons8.image = [UIImage imageNamed:@"q.png"];
        WiFi = NO;
        [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
    } else {
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitDevIconURL]];
            dispatch_async(dispatch_get_main_queue(), ^{
                _exploitDevImg.image = [UIImage imageWithData:imageData];
                dispatch_async(dispatch_get_global_queue(0,0), ^{
                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitForkDevIconURL]];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        _exploitForkDevImg.image = [UIImage imageWithData:imageData];
                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://php.eclipseemu.me/twitter/?id=1GamerDev"]];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                _me.image = [UIImage imageWithData:imageData];
                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://php.eclipseemu.me/twitter/?id=Skittyblock"]];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        _skitty.image = [UIImage imageWithData:imageData];
                                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://php.eclipseemu.me/twitter/?id=B1n4r1b01"]];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                _b.image = [UIImage imageWithData:imageData];
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    _b.image = [UIImage imageWithData:imageData];
                                                    dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                        imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:@"https://maxcdn.icons8.com/Share/icon/color/Logos/icons8_logo1600.png"]];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            _icons8.image = [UIImage imageWithData:imageData];
                                                            dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                if (![codesigner isEqual: @"Your username / alias"]) {
                                                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: codesignerIcon]];
                                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                                        _enterpriseCodeSignerIcon.image = [UIImage imageWithData:imageData];
                                                                        imageData = NULL;
                                                                    });
                                                                } else {
                                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                                        imageData = NULL;
                                                                    });
                                                                }
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(roundCredits) userInfo:nil repeats:YES];
    [timer fire];
}

- (void)viewDidLayoutSubviews {
    struct utsname u;
    uname(&u);
    if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 320);
    } else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 210);
    } else {
        if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 170);
        }
    }
}

@end

@interface fonts ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextField *urlf;
@property (strong, nonatomic) IBOutlet UIButton *change;
@property (strong, nonatomic) IBOutlet UISegmentedControl *o;
@property (strong, nonatomic) IBOutlet UIButton *cancel;
@property (strong, nonatomic) IBOutlet UIView *wait;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;

@end

@implementation fonts

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setAlpha:1.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
        } completion:^(BOOL finished) {
            [_wait setHidden:YES];
        }];
    }
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    if ([alertTitle isEqual: @"Success"]) {
        if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
    } else {
        [_respringBtn setHidden:YES];
    }
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)checkWiFiC {
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgDisabledColour];
        }];
        [_change setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgBlueColour];
        }];
        [_change setEnabled:YES];
    }
}

NSInteger emoji = -1;

- (void)viewWillAppear:(BOOL)animated {
    emoji = -1;
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)change:(id)sender {
    [self waitK];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
        int failure = 0;
        if ([_o selectedSegmentIndex] == 0) {
            emoji = 0;
        } else if ([_o selectedSegmentIndex] == 1) {
            emoji = 1;
        } else if ([_o selectedSegmentIndex] == 2) {
            emoji = 2;
        } else if ([_o selectedSegmentIndex] == 3) {
            emoji = 3;
        }
    method1:;
        NSLog(@"Method 1");
        if (emoji == 0) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/9ed8mtdu36cwpel/ios11.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        }
        else if (emoji == 1) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/v79f1mgqwxw4puy/androidoreo.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        }
        else if (emoji == 2) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/dss5l6912nbqssj/emojione.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else if (emoji == 3) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/ttsgje898eybmzi/twitter2.4.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else {
            [self doneWaiting];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                [self calert:@"Failed" alertMessage:@"No emoji was selected." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            });});
        }
        return;
    method2:;
        NSLog(@"Method 2");
        if (emoji == 0) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/ios11.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        }
        else if (emoji == 1) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/androidoreo.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        }
        else if (emoji == 2) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/emojione.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        } else if (emoji == 3) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/twitter2.4.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData)
            {
                [self doneWaiting];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        } else {
            [self doneWaiting];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                [self calert:@"Failed" alertMessage:@"No emoji was selected." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            });});
        }
        return;
    out0:;
        [self doneWaiting];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
            [self calert:@"Failed" alertMessage:@"Torngat was unable to download a required file." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        });});
        return;
    });});
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface bigFullscreenBoi ()
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;

@end

@implementation bigFullscreenBoi

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)calert {
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alert setHidden:NO]; [_X setHidden:NO];
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];}
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [_titleT setText:bigFullscreenBoiTitle];
    if ([bigFullscreenBoiTitle isEqual: @"Success"]) {
        if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
    } else {
        [_respringBtn setHidden:YES];
    }
    [_text setText:bigFullscreenBoiText];
    [self calert];
}

- (IBAction)cyaBruv:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];[self dismissViewControllerAnimated:NO completion:nil];});});
}

@end

@interface badges ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *colourDisplay;
@property (strong, nonatomic) IBOutlet UIButton *defaultBtn;
@property (strong, nonatomic) IBOutlet UIButton *transparent;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;
@property (strong, nonatomic) IBOutlet UISlider *opacitySlider;
@property (strong, nonatomic) IBOutlet UILabel *opacityValue;

@end

@implementation badges

float sliderVal;

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)changedSliderVal:(id)sender {
    [_opacityValue setText:[NSString stringWithFormat:@"%.01f", _opacitySlider.value]];
}

- (IBAction)useDefault:(id)sender {
    unlink("/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap");
    if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [_colourDisplay setBackgroundColor:hex(0xFF0000, 1.0)];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self applyBtn:_defaultBtn];
    [self applyBtn:_transparent];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(updateColour) userInfo:nil repeats:YES];
}

- (void)updateColour {
    unsint rgb = 0;
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", [hexv UTF8String]] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    if ([hexv length] != 6) {
        [UIView animateWithDuration:0.5f animations:^{
            [_colourDisplay setBackgroundColor:hex(0xFF0000, _opacitySlider.value)];
        }];
        return;
    }
    [UIView animateWithDuration:0.5f animations:^{
        [_colourDisplay setBackgroundColor:hex(rgb, _opacitySlider.value)];
    }];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

int size() {
    int detected;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        detected = 3;
    } else {
        detected = 2;
    }
    return detected;
}

UIImage *badge;

int bc(const char *colour, BOOL transparent) {
    /*
     // size 1.  i dont think any device uses this size but i wrote this code just in case.  contact me if (a) device(s) uses size 1 & which device(s) [it/they] [is/are] and i'll uncomment this.
     if (size() == 1) { UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 12, 12).size, NO, 0.0);
     CGContextRef context = UIGraphicsGetCurrentContext();
     CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
     CGRect size;
     if (transparent == FALSE) {
     size =  CGRectMake(0, 0, 12, 12);
     } else {
     size = CGRectMake(0, 0, 0, 0);
     }
     CGContextFillRect(context, size);
     badge = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     UIGraphicsBeginImageContextWithOptions(CGSizeMake(12.0, 12.0), NO, 0.0);
     CGRect bounds=(CGRect){CGPointZero, CGSizeMake(12.0, 12.0)};
     [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:6.0f] addClip];
     [badge drawInRect:bounds];
     badge = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     else */if (size() == 2) {
         UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 24, 24).size, NO, 0.0);
         CGContextRef context = UIGraphicsGetCurrentContext();
         CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
         CGRect size;
         if (transparent == FALSE) {
             size =  CGRectMake(0, 0, 24, 24);
         } else {
             size = CGRectMake(0, 0, 0, 0);
         }
         CGContextFillRect(context, size);
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
         UIGraphicsBeginImageContextWithOptions(CGSizeMake(24.0, 24.0), NO, 0.0);
         CGRect bounds=(CGRect){CGPointZero, CGSizeMake(24.0, 24.0)};
         [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:12.0f] addClip];
         [badge drawInRect:bounds];
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
     } else if (size() == 3) {
         UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 48, 48).size, NO, 0.0);
         CGContextRef context = UIGraphicsGetCurrentContext();
         CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
         CGRect size;
         if (transparent == FALSE) {
             size =  CGRectMake(0, 0, 48, 48);
         } else {
             size = CGRectMake(0, 0, 0, 0);
         }
         CGContextFillRect(context, size);
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
         UIGraphicsBeginImageContextWithOptions(CGSizeMake(48.0, 48.0), NO, 0.0);
         CGRect bounds=(CGRect){CGPointZero, CGSizeMake(48.0, 48.0)};
         [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:24.0f] addClip];
         [badge drawInRect:bounds];
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
     } else {
         return -2;
     }
    unsint rgb = 0;
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", colour] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    CGRect rect = CGRectMake(0, 0, badge.size.width, badge.size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context, rect, badge.CGImage);
    CGContextSetFillColorWithColor(context, [hex(rgb, sliderVal) CGColor]);
    CGContextFillRect(context, rect);
    badge = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [badge writeToCPBitmapFile:@"/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap" flags:1];
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap");
    int read_fd = open("/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap", O_RDONLY, 0);
    int write_fd = open("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", O_RDWR | O_CREAT | O_APPEND, 0777);
    if(fdopen(read_fd, "r") == NULL) {
        return -1;
    }
    if(fdopen(write_fd, "wb") == NULL) {
        return -1;
    }
    FILE *read_f = fdopen(read_fd, "r");
    FILE *write_f = fdopen(write_fd, "wb");
    size_t write_size;
    size_t read_size;
    while(feof(read_f) == 0) {
        char buff[100];
        if((read_size = fread(buff, 1, 100, read_f)) != 100) {
            if(ferror(read_f) != 0) {
                return -1;
            }
        }
        if((write_size = fwrite(buff, 1, read_size, write_f)) != read_size) {
            return -1;
        }
    }
    fclose(read_f);
    fclose(write_f);
    close(read_fd);
    close(write_fd);
    if (unlink("/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap") != 0) {
        return -1;
    }
    chown("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", 501, 501);
    chmod("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", 0666);
    return 1;
}

- (IBAction)transparent:(id)sender {
    if (bc([_hexf.text UTF8String], TRUE)) {
        if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
        [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
        [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)change:(id)sender {
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (![hexv isEqual: @""]) {
        if ([hexv length] == 6) {
            sliderVal = _opacitySlider.value;
            int ret = bc([_hexf.text UTF8String], FALSE);
            if (ret == 1) {
                if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
            } else if (ret == -2) {
                [self calert:@"Failed" alertMessage:@"Torngat could not detect the correct badge size." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            } else {
                [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Invalid hex code." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        }
    } else {
        [self calert:@"Failed" alertMessage:@"No hex code was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface aboutVC ()

@end

@implementation aboutVC

- (void)visualStyle {
    if(darkModeIsEnabled()) {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [_contentDisplay loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"darkAbout" ofType:@"html"]]]];
        [_contentDisplay setBackgroundColor:[UIColor blackColor]];
    } else {
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [_contentDisplay loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"about" ofType:@"html"]]]];
        [_contentDisplay setBackgroundColor:[UIColor whiteColor]];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

@end

@interface settings ()
@property (strong, nonatomic) IBOutlet UISwitch *darkModeSwitch;
@property (strong, nonatomic) IBOutlet UISwitch *loaderSwitch;
@property (strong, nonatomic) IBOutlet UISwitch *autoExploitSwitch;
@property (strong, nonatomic) IBOutlet UILabel *darkModeText;
@property (strong, nonatomic) IBOutlet UILabel *loadingSpinnerText;
@property (strong, nonatomic) IBOutlet UILabel *exploitAutomaticallyText;
@property (strong, nonatomic) IBOutlet UITableViewCell *darkModeCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *loadingSpinnerCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *exploitAutomaticallyCell;
@property (strong, nonatomic) IBOutlet UISwitch *resizeBootlogosSwitch;
@property (strong, nonatomic) IBOutlet UITableViewCell *resizeCell;
@property (strong, nonatomic) IBOutlet UILabel *resizeText;

@end

@implementation settings

- (void)viewWillAppear:(BOOL)animated {
    [self.darkModeCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.loadingSpinnerCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.resizeCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.exploitAutomaticallyCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    if ([stringWithContentsOfLocalFile(@"darkMode") isEqual: @"yes"]) {
        [_darkModeSwitch setOn:YES animated:NO];
    } else {
        [_darkModeSwitch setOn:NO animated:NO];
    }
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_loaderSwitch setOn:YES animated:NO];
    } else {
        [_loaderSwitch setOn:NO animated:NO];
    }
    if ([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
        [_autoExploitSwitch setOn:YES animated:NO];
    } else {
        [_autoExploitSwitch setOn:NO animated:NO];
    }
    if([stringWithContentsOfLocalFile(@"resizeBootlogos") isEqual: @"yes"]) {
        [_resizeBootlogosSwitch setOn:YES animated:NO];
    } else {
        [_resizeBootlogosSwitch setOn:NO animated:NO];
    }
    if (darkModeIsEnabled()) {
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.view setBackgroundColor:[UIColor blackColor]];
        _darkModeText.textColor = [UIColor whiteColor];
        _loadingSpinnerText.textColor = [UIColor whiteColor];
        _exploitAutomaticallyText.textColor = [UIColor whiteColor];
        _resizeText.textColor = [UIColor whiteColor];
        _darkModeCell.backgroundColor = [UIColor blackColor];
        _loadingSpinnerCell.backgroundColor = [UIColor blackColor];
        _exploitAutomaticallyCell.backgroundColor = [UIColor blackColor];
        _resizeCell.backgroundColor = [UIColor blackColor];
    } else {
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.view setBackgroundColor:[UIColor whiteColor]];
        _darkModeText.textColor = [UIColor blackColor];
        _loadingSpinnerText.textColor = [UIColor blackColor];
        _exploitAutomaticallyText.textColor = [UIColor blackColor];
        _resizeText.textColor = [UIColor blackColor];
        _darkModeCell.backgroundColor = [UIColor whiteColor];
        _loadingSpinnerCell.backgroundColor = [UIColor whiteColor];
        _exploitAutomaticallyCell.backgroundColor = [UIColor whiteColor];
        _resizeCell.backgroundColor = [UIColor whiteColor];
    }
    if (SYSTEM_VERSION_GREATER_THAN(@"11.1.2")) {
        [_resizeBootlogosSwitch setEnabled:NO];
        [_resizeText setTextColor:[UIColor grayColor]];
    }
}

- (void)enableDarkMode {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.2f animations:^{
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.view setBackgroundColor:[UIColor blackColor]];
        _darkModeText.textColor = [UIColor whiteColor];
        _loadingSpinnerText.textColor = [UIColor whiteColor];
        _exploitAutomaticallyText.textColor = [UIColor whiteColor];
        _resizeText.textColor = [UIColor whiteColor];
        _darkModeCell.backgroundColor = [UIColor blackColor];
        _loadingSpinnerCell.backgroundColor = [UIColor blackColor];
        _exploitAutomaticallyCell.backgroundColor = [UIColor blackColor];
        _resizeCell.backgroundColor = [UIColor blackColor];
    }];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updatedVisualStyle" object:self];
}

- (void)disableDarkMode {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];
    [UIView animateWithDuration:0.2f animations:^{
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.view setBackgroundColor:[UIColor whiteColor]];
        _darkModeText.textColor = [UIColor blackColor];
        _loadingSpinnerText.textColor = [UIColor blackColor];
        _exploitAutomaticallyText.textColor = [UIColor blackColor];
        _resizeText.textColor = [UIColor blackColor];
        _darkModeCell.backgroundColor = [UIColor whiteColor];
        _loadingSpinnerCell.backgroundColor = [UIColor whiteColor];
        _exploitAutomaticallyCell.backgroundColor = [UIColor whiteColor];
        _resizeCell.backgroundColor = [UIColor whiteColor];
    }];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updatedVisualStyle" object:self];
}

- (IBAction)toggleDarkMode:(id)sender {
    if ([_darkModeSwitch isOn]) {
        writeToLocalFile(@"darkMode", @"yes");
        [self enableDarkMode];
    } else {
        writeToLocalFile(@"darkMode", @"no");
        [self disableDarkMode];
    }
}

- (IBAction)toggleLoader:(id)sender {
    if ([_loaderSwitch isOn]) {
        writeToLocalFile(@"showLoader", @"yes");
    } else {
        writeToLocalFile(@"showLoader", @"no");
    }
}

- (IBAction)toggleAutoExploit:(id)sender {
    if ([_autoExploitSwitch isOn]) {
        writeToLocalFile(@"autoExploit", @"yes");
    } else {
        writeToLocalFile(@"autoExploit", @"no");
    }
}

- (IBAction)toggleResizeBootlogos:(id)sender {
    if ([_autoExploitSwitch isOn]) {
        writeToLocalFile(@"resizeBootlogos", @"yes");
    } else {
        writeToLocalFile(@"resizeBootlogos", @"no");
    }
}

@end

@interface dockLine ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *colourDisplay;
@property (strong, nonatomic) IBOutlet UIButton *defaultBtn;
@property (strong, nonatomic) IBOutlet UIButton *transparent;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;
@property (strong, nonatomic) IBOutlet UISlider *heightSlider;
@property (strong, nonatomic) IBOutlet UILabel *heightValue;

@end

@implementation dockLine

float sliderVal;

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)useDefault:(id)sender {
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap");
    if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [_colourDisplay setBackgroundColor:hex(0x000000, 1.0)];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self applyBtn:_defaultBtn];
    [self applyBtn:_transparent];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(updateColour) userInfo:nil repeats:YES];
}

- (void)updateColour {
    unsint rgb = 0;
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", [hexv UTF8String]] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    if ([hexv length] != 6) {
        [UIView animateWithDuration:0.5f animations:^{
            [_colourDisplay setBackgroundColor:hex(0x000000, 1.0)];
        }];
        return;
    }
    [UIView animateWithDuration:0.5f animations:^{
        [_colourDisplay setBackgroundColor:hex(rgb, 1.0)];
    }];
}

- (IBAction)updateHeightVal:(id)sender {
    [_heightValue setText:[NSString stringWithFormat:@"%.01f", _heightSlider.value]];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

UIImage *line;
int lc(const char *colour, BOOL transparent) {
    UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 10000, sliderVal).size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
    CGRect size;
    if (transparent == FALSE) {
        size = CGRectMake(0, 0, 10000, sliderVal);
    } else {
        size = CGRectMake(0, 0, 0, 0);
    }
    CGContextFillRect(context, size);
    line = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    unsint rgb = 0;
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", colour] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    CGRect rect = CGRectMake(0, 0, 10000, sliderVal);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0);
    CGContextRef anotherContext = UIGraphicsGetCurrentContext();
    CGContextClipToMask(anotherContext, rect, line.CGImage);
    CGContextSetFillColorWithColor(anotherContext, [hex(rgb, 1.0) CGColor]);
    CGContextFillRect(anotherContext, rect);
    line = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [line writeToCPBitmapFile:@"/private/var/mobile/Documents/DockLine_Torngat.cpbitmap" flags:1];
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap");
    int read_fd = open("/private/var/mobile/Documents/DockLine_Torngat.cpbitmap", O_RDONLY, 0);
    int write_fd = open("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", O_RDWR | O_CREAT | O_APPEND, 0777);
    if(fdopen(read_fd, "r") == NULL) {
        return -1;
    }
    if(fdopen(write_fd, "wb") == NULL) {
        return -1;
    }
    FILE *read_f = fdopen(read_fd, "r");
    FILE *write_f = fdopen(write_fd, "wb");
    size_t write_size;
    size_t read_size;
    while(feof(read_f) == 0) {
        char buff[100];
        if((read_size = fread(buff, 1, 100, read_f)) != 100) {
            if(ferror(read_f) != 0) {
                return -1;
            }
        }
        if((write_size = fwrite(buff, 1, read_size, write_f)) != read_size) {
            return -1;
        }
    }
    fclose(read_f);
    fclose(write_f);
    close(read_fd);
    close(write_fd);
    if (unlink("/private/var/mobile/Documents/DockLine_Torngat.cpbitmap") != 0) {
        return -1;
    }
    chown("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", 501, 501);
    chmod("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", 0666);
    return 1;
}

- (IBAction)transparent:(id)sender {
    if (lc([_hexf.text UTF8String], TRUE)) {
        if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
        [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
        [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)change:(id)sender {
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (![hexv isEqual: @""]) {
        if ([hexv length] == 6) {
            sliderVal = [[NSString stringWithFormat:@"%.01f", _heightSlider.value] floatValue];
            int ret = lc([_hexf.text UTF8String], FALSE);
            if (ret == 1) {
                if (SYSTEM_VERSION_LESS_THAN(@"11.2")){[_respringBtn setHidden:NO];}
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
            } else if (ret == -2) {
                [self calert:@"Failed" alertMessage:@"Torngat could not detect the correct line size." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            } else {
                [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Invalid hex code." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        }
    } else {
        [self calert:@"Failed" alertMessage:@"No hex code was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end
