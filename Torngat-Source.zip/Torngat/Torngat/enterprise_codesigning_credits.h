// If you're planning to codesign and re-distribute Torngat with an enterprise certificate, edit the two lines below.
#define codesigner @"Your username / alias"
#define codesignerIcon @"URL to the icon which will be displayed"
